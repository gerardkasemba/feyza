export { NotificationsPageClient } from './NotificationsPageClient';
